package steps;

import static org.junit.Assert.assertEquals;

import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;

import cucumber.api.java.pt.Dado;
import cucumber.api.java.pt.Quando;
import cucumber.api.java.pt.Entao;
import cucumber.api.java.pt.E;

public class protoCommerceSteps {

	private int i;
	Random gerador = new Random();
	int total = gerador.nextInt(6)+1;
	private static WebDriver driver;
	
	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver", ".\\lib\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://rahulshettyacademy.com/angularpractice/shop");
	}

    @Dado("^que esteja na Home$")
    public void queEstejaNaHome() throws Throwable {
    	driver.get("https://rahulshettyacademy.com/angularpractice/");
    }
    @Quando("^preencher o formulario$")
    public void preencherOFormulario() throws Throwable {
    	driver.findElement(By.name("name")).sendKeys("Novo Usu�rio");
    	driver.findElement(By.name("email")).sendKeys("novo_usuario@teste.com");
    	driver.findElement(By.id("exampleInputPassword1")).sendKeys("xyz123");
    	driver.findElement(By.id("exampleCheck1")).click();

    	//randomiza qual radio usar
    	int id = gerador.nextInt(2);
    	if (id==0) {
    		id=+1;
    	} else {
    		driver.findElement(By.id("inlineRadio"+id)).click();
    	}
    	driver.findElement(By.name("name")).sendKeys("01012000");
    }

    @E("^acionar o botao Submit$")
    public void acionarOBotaoSubmit() throws Throwable {
    	driver.findElement(By.xpath("//input[@value='Submit']")).click();
    }
    
    @Entao("^o sistema exibe mensagem de sucesso$")
    public void oSistemaExibeMensagemDeSucesso() throws Throwable {
    	driver.getPageSource().contains("The Form has been submitted successfully!");
    }
	
	
	
	@Dado("^que esteja na pagina de produtos$")
	public void queEstejaNaPaginaDeProdutos() throws Throwable {
		driver.findElement(By.partialLinkText("Checkout"));
	}
	
	@Quando("^acionar o botao Add de mais de um produto$")
	public void acionarOBotaoAddDeMaisDeUmProduto() throws Throwable {
		for (i=1; i<=total; i++) {
			int item = gerador.nextInt(3)+1;
			driver.findElement(By.xpath("/html/body/app-root/app-shop/div/div/div[2]/app-card-list/app-card["+item+"]/div/div[2]/button")).click();
		}
		String itens = driver.findElement(By.partialLinkText("Checkout")).getText().substring(11, 12);
		assertEquals(Integer.parseInt(itens),total);
	}

	@E("^acionar o botao Checkout$")
	public void acionarOBotaoCheckout() throws Throwable {
		driver.findElement(By.partialLinkText("Checkout")).click();
	}

	@E("^acionar o botao Continue Shopping$")
	public void acionarOBotaoContinueShopping() throws Throwable {
		driver.findElement(By.xpath("//button[@class='btn btn-default'][contains(.,'Continue Shopping')]")).click();
	}

	@Entao("^o sistema retorna para a pagina de compras")
	public void oSistemaRetornaParaAPaginaDeCompras() throws Throwable {
		driver.findElement(By.linkText("Category 1")).isDisplayed();
	}

	@E("^exibe no Checkout os produtos ja selecionados$")
	public void exibeNoCheckoutOsProdutosJaSelecionados() throws Throwable {
		String itens = driver.findElement(By.partialLinkText("Checkout")).getText().substring(11, 12);
		
		//Aqui ocorre falha pois ao utilizar o bot�o COntinue Shopping o Carrinho/Checkout � zerado
		assertEquals(Integer.parseInt(itens),total);
	}

    @After
    public void tearDown(){
    	driver.close();
    	driver.quit();
    }
}
